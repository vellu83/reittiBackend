const mongoose = require('mongoose')



if (process.argv.length < 3) {
    console.log('give password as argument')
    process.exit(1)
}

const taxicompanyArg = process.argv[2]
console.log(taxicompanyArg)

const url = process.env.MONGODB_URI

    mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true })


const taxicompanySchema = new mongoose.Schema({
    name: String,
    arkihintaLahto: Number,
    arkihintaMinuutti: Number,
    arkihintaKilometri: Number,
    pyhahintaLahto: Number,
    pyhahintaMinuutti: Number,
    pyhahintaKilometri: Number,
    yohintaLahto: Number,
    yohintaMinuutti: Number,
    yohintaKilometri: Number,

})

const Taxicompany = mongoose.model('Taxicompany', taxicompanySchema)

if (taxicompanyArg === 'PRINT') {
    Taxicompany.find({}).then(result => {
        console.log('Kuljetusfirmat tietokannassa:')
        result.forEach(person => {
            console.log(person.name)
        })
        mongoose.connection.close()
    })
} else {
    const taxicompany = new Taxicompany({
        name: taxicompanyArg.name,
        arkihintaLahto: taxicompanyArg.arkihintaLahto,
        arkihintaMinuutti: taxicompanyArg.arkihintaMinuutti,
        arkihintaKilometri: taxicompanyArg.arkihintaKilometri,
        pyhahintaLahto: taxicompanyArg.pyhahintaLahto,
        pyhahintaMinuutti: taxicompanyArg.pyhahintaMinuutti,
        pyhahintaKilometri: taxicompanyArg.pyhahintaKilometri,
        yohintaLahto: taxicompanyArg.yohintaLahto,
        yohintaMinuutti: taxicompanyArg.yohintaMinuutti,
        yohintaKilometri: taxicompanyArg.yohintaKilometri
    })
    taxicompany.save().then(result => {
        console.log(`added ${taxicompany.name} to database`)
        mongoose.connection.close()
    })

}