const mongoose = require('mongoose')
const uniqueValidator = require('mongoose-unique-validator')
require('dotenv').config({ path: '../.env' })

const url = process.env.MONGODB_URI

const taxicompanyArg = process.argv
console.log(taxicompanyArg[2])

console.log('connecting to', url)
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true })
    .then(result => {
        console.log('connected to MongoDB')
    })
    .catch((error) => {
        console.log('error connecting to DB:', error.message)
    })

const taxicompanySchema = new mongoose.Schema({
    name: { type: String, required: true, minlength: 3 },
    arkihintaLahto: { type: Number, required: true },
    arkihintaMinuutti: { type: Number, required: true },
    arkihintaKilometri: { type: Number, required: true },
    pyhahintaLahto: { type: Number, required: true },
    pyhahintaMinuutti: { type: Number, required: true },
    pyhahintaKilometri: { type: Number, required: true },
    yohintaLahto: { type: Number, required: true },
    yohintaMinuutti: { type: Number, required: true },
    yohintaKilometri: { type: Number, required: true }
})

taxicompanySchema.plugin(uniqueValidator)

const Taxicompany = mongoose.model('Taxicompany', taxicompanySchema)

try {

    if (taxicompanyArg[2] === 'PRINT') {
        Taxicompany.find({}).then(result => {
            console.log('Kuljetusfirmat tietokannassa:')
            result.forEach(person => {
                console.log(person.name)
            })
            mongoose.connection.close()
        })
    } else if (taxicompanySchema[2]) {
        const taxicompany = new Taxicompany({
            name: taxicompanyArg[2],
            arkihintaLahto: taxicompanyArg[3],
            arkihintaMinuutti: taxicompanyArg[4],
            arkihintaKilometri: taxicompanyArg[5],
            pyhahintaLahto: taxicompanyArg[6],
            pyhahintaMinuutti: taxicompanyArg[7],
            pyhahintaKilometri: taxicompanyArg[8],
            yohintaLahto: taxicompanyArg[9],
            yohintaMinuutti: taxicompanyArg[10],
            yohintaKilometri: taxicompanyArg[11],
        })

        taxicompany.save().then(result => {
            console.log(`added ${taxicompany.name} to database`)
            mongoose.connection.close()
        })
    }
} catch (error) {
    console.log(error)
}

taxicompanySchema.set('toJSON', {
    transform: (document, returnedObject) => {
        returnedObject.id = returnedObject._id.toString()
        delete returnedObject._id
        delete returnedObject.__v
    }
})

module.exports = mongoose.model('Taxicompany', taxicompanySchema)